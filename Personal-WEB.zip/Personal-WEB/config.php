<?php
session_start();

$host = 'localhost';
$user = 'root';
$pass = ''; // Default XAMPP password is empty
$dbname = 'personal_web';

// Attempt connection without database first
$conn = new mysqli($host, $user, $pass);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if it doesn't exist
$conn->query("CREATE DATABASE IF NOT EXISTS `$dbname`");

// Select the database
$conn->select_db($dbname);

// Auto-run database.sql if 'users' table doesn't exist
$check_table = $conn->query("SHOW TABLES LIKE 'users'");
if ($check_table && $check_table->num_rows == 0) {
    $sql_file = __DIR__ . '/database.sql';
    if (file_exists($sql_file)) {
        $sql = file_get_contents($sql_file);
        if ($conn->multi_query($sql)) {
            while ($conn->next_result()) {;} // Flush pending results
        }
    }
}

// Helper function to check if logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}
?>
