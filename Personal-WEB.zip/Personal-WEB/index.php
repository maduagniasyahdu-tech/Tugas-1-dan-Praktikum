<?php
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Personal Web</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .main-content-area {
            min-height: 500px;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }
    </style>
</head>
<body>

<div class="container mt-4">
    <!-- Header: 12 grid -->
    <div class="row mb-3">
        <div class="col-12">
            <?php include 'header.php'; ?>
        </div>
    </div>

    <!-- Menu: 12 grid -->
    <div class="row mb-3">
        <div class="col-12">
            <?php include 'menu.php'; ?>
        </div>
    </div>

    <!-- Content Area: Sidebar 3 grid, Main 9 grid -->
    <div class="row mb-3">
        <div class="col-md-3">
            <?php include 'sidebar.php'; ?>
        </div>
        <div class="col-md-9">
            <div class="main-content-area">
                <?php include 'main.php'; ?>
            </div>
        </div>
    </div>

    <!-- Footer: 12 grid -->
    <div class="row">
        <div class="col-12">
            <?php include 'footer.php'; ?>
        </div>
    </div>
</div>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
