<div class="alert alert-secondary text-center shadow-sm" role="alert">
  &copy; <?= date('Y') ?> My Personal Web. Built with <i class="bi bi-heart-fill text-danger"></i> using Bootstrap 5 & PHP.
</div>
