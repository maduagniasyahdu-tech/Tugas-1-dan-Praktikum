<div id="headerCarousel" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#headerCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#headerCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#headerCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner rounded shadow-sm">
    <div class="carousel-item active">
      <img src="img/header1.jpg" class="d-block w-100" alt="Code 1" style="object-fit: cover; height: 300px;">
      <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
        <h5>Welcome to My Personal Web</h5>
        <p>A showcase of my journey and skills.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/header2.jpg" class="d-block w-100" alt="Code 2" style="object-fit: cover; height: 300px;">
      <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
        <h5>Continuous Learning</h5>
        <p>Always exploring new technologies.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/header3.jpg" class="d-block w-100" alt="Code 3" style="object-fit: cover; height: 300px;">
      <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
        <h5>Projects & Experience</h5>
        <p>Building things that matter.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#headerCarousel" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#headerCarousel" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
