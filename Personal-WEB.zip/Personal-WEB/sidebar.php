<?php
$current_page = isset($_GET['page']) ? $_GET['page'] : 'home';
?>
<div class="list-group shadow-sm">
  <a href="?page=home" class="list-group-item list-group-item-action <?= $current_page == 'home' ? 'active' : '' ?>">
    <i class="bi bi-house-door-fill me-2"></i> Home
  </a>
  <a href="?page=about" class="list-group-item list-group-item-action <?= $current_page == 'about' ? 'active' : '' ?>">
    <i class="bi bi-person-lines-fill me-2"></i> About Me
  </a>
  <a href="?page=contact" class="list-group-item list-group-item-action <?= $current_page == 'contact' ? 'active' : '' ?>">
    <i class="bi bi-envelope-fill me-2"></i> Contact Me
  </a>
  <a href="?page=level" class="list-group-item list-group-item-action <?= $current_page == 'level' ? 'active' : '' ?>">
    <i class="bi bi-bar-chart-fill me-2"></i> Education Levels
  </a>
  <a href="?page=studies" class="list-group-item list-group-item-action <?= $current_page == 'studies' ? 'active' : '' ?>">
    <i class="bi bi-book-fill me-2"></i> My Studies
  </a>
</div>
