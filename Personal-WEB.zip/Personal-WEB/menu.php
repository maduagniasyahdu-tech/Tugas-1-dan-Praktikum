<?php
$current_page = isset($_GET['page']) ? $_GET['page'] : 'home';
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary rounded shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand" href="?page=home"><i class="bi bi-person-circle"></i> PersonalWeb</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link <?= $current_page == 'home' ? 'active' : '' ?>" aria-current="page" href="?page=home">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $current_page == 'about' ? 'active' : '' ?>" href="?page=about">About Me</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $current_page == 'contact' ? 'active' : '' ?>" href="?page=contact">Contact Me</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?= in_array($current_page, ['level', 'studies']) ? 'active' : '' ?>" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            My Studies
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="?page=level">Level</a></li>
            <li><a class="dropdown-item" href="?page=studies">Studies</a></li>
          </ul>
        </li>
      </ul>
      <ul class="navbar-nav">
        <?php if (isLoggedIn()): ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-person-fill"></i> <?= htmlspecialchars($_SESSION['user_name']) ?> (<?= htmlspecialchars($_SESSION['user_role']) ?>)
              </a>
              <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                <li><a class="dropdown-item" href="?page=logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
              </ul>
            </li>
        <?php else: ?>
            <li class="nav-item">
              <a class="nav-link <?= $current_page == 'login' ? 'active' : '' ?>" href="?page=login"><i class="bi bi-box-arrow-in-right"></i> Login</a>
            </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
