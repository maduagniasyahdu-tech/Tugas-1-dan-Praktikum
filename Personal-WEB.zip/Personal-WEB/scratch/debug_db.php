<?php
include 'config.php';
$result = $conn->query("SELECT * FROM studies");
while($row = $result->fetch_assoc()) {
    print_r($row);
}
?>
