<?php
include 'config.php';

// Fix ID 2
$stmt = $conn->prepare("UPDATE studies SET foto_sekolah = '1778204797_9197.gif' WHERE id = 2 AND foto_sekolah = '1778204797'");
$stmt->execute();
echo "Fixed ID 2: " . $stmt->affected_rows . " row(s) updated\n";
$stmt->close();

// For ID 1, we don't know which one it is, so we'll leave it as 0 for now or set it to one of the available ones.
// Let's check if there are any other files.
?>
