<?php
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

// Basic routing
$allowed_pages = ['home', 'about', 'contact', 'login', 'logout', 'level', 'studies'];

if (in_array($page, $allowed_pages)) {
    $file = "pages/{$page}.php";
    if (file_exists($file)) {
        include $file;
    } else {
        echo "<div class='alert alert-danger'>Page file not found.</div>";
    }
} else {
    echo "<div class='alert alert-warning'>404 Not Found</div>";
}
?>
