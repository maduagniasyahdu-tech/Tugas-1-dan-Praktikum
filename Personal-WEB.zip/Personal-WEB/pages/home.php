<div class="card mb-3 shadow-sm border-0">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="img/madu.jpeg" class="img-fluid rounded-start h-100 object-fit-cover" alt="Profile Picture">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h3 class="card-title text-primary">About My Profile</h3>
        <p class="card-text">Hello! Saya Madu Agnia Syahdu Mahasiswa Teknik Informatika Angkatan 2025 dari Sekolah Tinggi Teknologi Terpadu Nurul Fikri.</p>
        <p class="card-text">Saya senang belajar hal baru seperti ngoding.</p>
        <p class="card-text"><small class="text-body-secondary">"This is my profile"</small></p>
      </div>
    </div>
  </div>
</div>
