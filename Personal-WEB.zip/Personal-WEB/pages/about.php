<h3 class="mb-4 text-primary border-bottom pb-2">More About Me</h3>

<div class="accordion shadow-sm" id="accordionAbout">
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        <i class="bi bi-controller me-2"></i> Hobby
      </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionAbout">
      <div class="accordion-body">
        <strong>Travelling dan Membaca</strong> Di sela-sela waktu free saya suka jogging dengan teman-teman saya
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
        <i class="bi bi-cup-hot-fill me-2"></i> Makanan Favorit
      </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionAbout">
      <div class="accordion-body">
        <strong>SUSHI</strong> Saya suka sekali sushi
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        <i class="bi bi-people-fill me-2"></i> Pengalaman Organisasi
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionAbout">
      <div class="accordion-body">
        <strong>MPK</strong> Saya menjadi pengawas event saat bergabung di MPK saat SMA
        <strong>Purna Paskibraka Indonesia 2023</strong> Saya menjadi anggota Pakibraka Kota Depok di Tahun 2023
      </div>
    </div>
  </div>
</div>
