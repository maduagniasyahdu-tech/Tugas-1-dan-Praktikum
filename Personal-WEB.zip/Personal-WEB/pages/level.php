<?php
$isLoggedIn = isLoggedIn();

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

// Protect mutating actions
if (in_array($action, ['add', 'edit', 'delete']) || $_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!$isLoggedIn) {
        echo "<div class='alert alert-danger'>Access denied. You must be logged in to perform this action. <a href='?page=login'>Login here</a></div>";
        return;
    }
}

// Handle Delete
if ($action == 'delete' && $id > 0) {
    $stmt = $conn->prepare("DELETE FROM level WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        echo "<script>alert('Record deleted successfully'); window.location.href='?page=level';</script>";
    } else {
        echo "<div class='alert alert-danger'>Error deleting record.</div>";
    }
    $stmt->close();
}

// Handle Add / Edit form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'] ?? '';
    if (!empty($nama)) {
        if ($id > 0) {
            // Update
            $stmt = $conn->prepare("UPDATE level SET nama = ? WHERE id = ?");
            $stmt->bind_param("si", $nama, $id);
            $stmt->execute();
            $stmt->close();
            echo "<script>alert('Record updated successfully'); window.location.href='?page=level';</script>";
        } else {
            // Insert
            $stmt = $conn->prepare("INSERT INTO level (nama) VALUES (?)");
            $stmt->bind_param("s", $nama);
            $stmt->execute();
            $stmt->close();
            echo "<script>alert('Record added successfully'); window.location.href='?page=level';</script>";
        }
    } else {
        echo "<div class='alert alert-danger'>Name cannot be empty.</div>";
    }
}

// Show Form for Add/Edit
if ($action == 'add' || $action == 'edit') {
    $nama = '';
    if ($action == 'edit' && $id > 0) {
        $stmt = $conn->prepare("SELECT nama FROM level WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            $nama = $row['nama'];
        }
        $stmt->close();
    }
    ?>
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <?= $action == 'add' ? 'Add' : 'Edit' ?> Level
        </div>
        <div class="card-body">
            <form method="POST" action="?page=level&action=<?= $action ?><?= $id > 0 ? '&id='.$id : '' ?>">
                <div class="mb-3">
                    <label class="form-label">Level Name</label>
                    <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($nama) ?>" required>
                </div>
                <button type="submit" class="btn btn-success">Save</button>
                <a href="?page=level" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
    <?php
} else {
    // List view
    ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Education Levels</h3>
        <?php if ($isLoggedIn): ?>
            <a href="?page=level&action=add" class="btn btn-primary"><i class="bi bi-plus-circle"></i> Add New</a>
        <?php endif; ?>
    </div>
    <div class="table-responsive shadow-sm">
        <table class="table table-bordered table-striped table-hover mb-0">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <?php if ($isLoggedIn): ?>
                        <th width="150">Action</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM level ORDER BY id ASC");
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>{$row['id']}</td>";
                        echo "<td>" . htmlspecialchars($row['nama']) . "</td>";
                        if ($isLoggedIn) {
                            echo "<td>
                                    <a href='?page=level&action=edit&id={$row['id']}' class='btn btn-sm btn-warning'><i class='bi bi-pencil'></i> Edit</a>
                                    <a href='?page=level&action=delete&id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure?\")'><i class='bi bi-trash'></i> Delete</a>
                                  </td>";
                        }
                        echo "</tr>";
                    }
                } else {
                    $colspan = $isLoggedIn ? 3 : 2;
                    echo "<tr><td colspan='{$colspan}' class='text-center'>No records found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
}
?>
