<h3 class="mb-4 text-primary border-bottom pb-2">Connect With Me</h3>

<div class="card-group shadow-sm">
  <div class="card text-center border-0 border-end">
    <div class="card-body">
      <i class="bi bi-github display-4 text-dark mb-3"></i>
      <h5 class="card-title">GitHub</h5>
      <p class="card-text">Check out my open-source projects and contributions.</p>
    </div>
    <div class="card-footer bg-white border-top-0">
      <a href="https://github.com/maduagniasyahdu-tech" target="_blank" class="btn btn-outline-dark btn-sm">Visit Profile</a>
    </div>
  </div>
  <div class="card text-center border-0 border-end">
    <div class="card-body">
      <i class="bi bi-linkedin display-4 text-primary mb-3"></i>
      <h5 class="card-title">LinkedIn</h5>
      <p class="card-text">Let's connect professionally and grow our network.</p>
    </div>
    <div class="card-footer bg-white border-top-0">
      <a href="https://www.linkedin.com/in/madu-agnia-syahdu-45a88b386?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" target="_blank" class="btn btn-outline-primary btn-sm">Connect</a>
    </div>
  </div>
  <div class="card text-center border-0">
    <div class="card-body">
      <i class="bi bi-instagram display-4 text-danger mb-3"></i>
      <h5 class="card-title">Instagram</h5>
      <p class="card-text">A glimpse into my daily life and personal moments.</p>
    </div>
    <div class="card-footer bg-white border-top-0">
      <a href="https://www.instagram.com/agniasyaa?igsh=bzNxbjYydng4Ymo4" target="_blank" class="btn btn-outline-danger btn-sm">Follow Me</a>
    </div>
  </div>
</div>
