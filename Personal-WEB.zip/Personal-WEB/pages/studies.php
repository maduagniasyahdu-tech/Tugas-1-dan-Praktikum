<?php
$isLoggedIn = isLoggedIn();

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

// Protect mutating actions
if (in_array($action, ['add', 'edit', 'delete']) || $_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!$isLoggedIn) {
        echo "<div class='alert alert-danger'>Access denied. You must be logged in to perform this action. <a href='?page=login'>Login here</a></div>";
        return;
    }
}

$upload_dir = 'uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Handle Delete
if ($action == 'delete' && $id > 0) {
    // get old photo to delete
    $stmt = $conn->prepare("SELECT foto_sekolah FROM studies WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        if (!empty($row['foto_sekolah']) && file_exists($upload_dir . $row['foto_sekolah'])) {
            unlink($upload_dir . $row['foto_sekolah']);
        }
    }
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM studies WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        echo "<script>alert('Record deleted successfully'); window.location.href='?page=studies';</script>";
    }
    $stmt->close();
}

// Handle Add / Edit form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'] ?? '';
    $idlevel = $_POST['idlevel'] ?? 0;
    $keterangan = $_POST['keterangan'] ?? '';
    $tahun_lulus = $_POST['tahun_lulus'] ?? '';
    
    // File upload logic
    $foto_sekolah = $_POST['old_foto'] ?? '';
    if (isset($_FILES['foto_sekolah']) && $_FILES['foto_sekolah']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['foto_sekolah']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (in_array($ext, $allowed)) {
            $new_filename = time() . '_' . rand(1000, 9999) . '.' . $ext;
            if (move_uploaded_file($_FILES['foto_sekolah']['tmp_name'], $upload_dir . $new_filename)) {
                // Remove old file if exists
                if (!empty($foto_sekolah) && file_exists($upload_dir . $foto_sekolah)) {
                    unlink($upload_dir . $foto_sekolah);
                }
                $foto_sekolah = $new_filename;
            }
        }
    }

    if (!empty($nama) && $idlevel > 0) {
        if ($id > 0) {
            $stmt = $conn->prepare("UPDATE studies SET nama=?, idlevel=?, keterangan=?, tahun_lulus=?, foto_sekolah=? WHERE id=?");
            $stmt->bind_param("sisssi", $nama, $idlevel, $keterangan, $tahun_lulus, $foto_sekolah, $id);
            $stmt->execute();
            $stmt->close();
            echo "<script>alert('Record updated successfully'); window.location.href='?page=studies';</script>";
        } else {
            $stmt = $conn->prepare("INSERT INTO studies (nama, idlevel, keterangan, tahun_lulus, foto_sekolah) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sisss", $nama, $idlevel, $keterangan, $tahun_lulus, $foto_sekolah);
            $stmt->execute();
            $stmt->close();
            echo "<script>alert('Record added successfully'); window.location.href='?page=studies';</script>";
        }
    } else {
        echo "<div class='alert alert-danger'>Name and Level are required.</div>";
    }
}

// Show Form for Add/Edit
if ($action == 'add' || $action == 'edit') {
    $study = ['nama'=>'', 'idlevel'=>'', 'keterangan'=>'', 'tahun_lulus'=>'', 'foto_sekolah'=>''];
    if ($action == 'edit' && $id > 0) {
        $stmt = $conn->prepare("SELECT * FROM studies WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            $study = $row;
        }
        $stmt->close();
    }
    
    // Fetch levels for dropdown
    $levels = [];
    $res = $conn->query("SELECT * FROM level");
    while($row = $res->fetch_assoc()) $levels[] = $row;
    
    ?>
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <?= $action == 'add' ? 'Add' : 'Edit' ?> Study
        </div>
        <div class="card-body">
            <form method="POST" action="?page=studies&action=<?= $action ?><?= $id > 0 ? '&id='.$id : '' ?>" enctype="multipart/form-data">
                <input type="hidden" name="old_foto" value="<?= htmlspecialchars($study['foto_sekolah']) ?>">
                <div class="mb-3">
                    <label class="form-label">Institution Name</label>
                    <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($study['nama']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Education Level</label>
                    <select name="idlevel" class="form-select" required>
                        <option value="">Select Level</option>
                        <?php foreach($levels as $lvl): ?>
                            <option value="<?= $lvl['id'] ?>" <?= $study['idlevel'] == $lvl['id'] ? 'selected' : '' ?>><?= htmlspecialchars($lvl['nama']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Description</label>
                    <textarea name="keterangan" class="form-control" rows="3"><?= htmlspecialchars($study['keterangan']) ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Graduation Year</label>
                    <input type="number" name="tahun_lulus" class="form-control" value="<?= htmlspecialchars($study['tahun_lulus']) ?>" min="1900" max="2100">
                </div>
                <div class="mb-3">
                    <label class="form-label">School Photo</label>
                    <input type="file" name="foto_sekolah" class="form-control" accept="image/*">
                    <?php if(!empty($study['foto_sekolah'])): ?>
                        <div class="mt-2">
                            <img src="uploads/<?= $study['foto_sekolah'] ?>" width="100" class="img-thumbnail" alt="Current Photo">
                        </div>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-success">Save</button>
                <a href="?page=studies" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
    <?php
} else {
    // List view
    ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>My Studies</h3>
        <?php if ($isLoggedIn): ?>
            <a href="?page=studies&action=add" class="btn btn-primary"><i class="bi bi-plus-circle"></i> Add New</a>
        <?php endif; ?>
    </div>
    <div class="table-responsive shadow-sm">
        <table class="table table-bordered table-striped table-hover mb-0">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Institution</th>
                    <th>Level</th>
                    <th>Year</th>
                    <th>Photo</th>
                    <?php if ($isLoggedIn): ?>
                        <th width="150">Action</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT s.*, l.nama as level_nama FROM studies s LEFT JOIN level l ON s.idlevel = l.id ORDER BY s.tahun_lulus DESC";
                $result = $conn->query($query);
                if ($result && $result->num_rows > 0) {
                    $no = 1;
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>{$no}</td>";
                        $no++;
                        echo "<td>" . htmlspecialchars($row['nama']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['level_nama']) . "</td>";
                        echo "<td>{$row['tahun_lulus']}</td>";
                        echo "<td>";
                        if (!empty($row['foto_sekolah'])) {
                            echo "<img src='uploads/{$row['foto_sekolah']}' height='50' class='rounded border'>";
                        } else {
                            echo "<span class='text-muted'>No image</span>";
                        }
                        echo "</td>";
                        if ($isLoggedIn) {
                            echo "<td>
                                    <a href='?page=studies&action=edit&id={$row['id']}' class='btn btn-sm btn-warning mb-1'><i class='bi bi-pencil'></i></a>
                                    <a href='?page=studies&action=delete&id={$row['id']}' class='btn btn-sm btn-danger mb-1' onclick='return confirm(\"Are you sure?\")'><i class='bi bi-trash'></i></a>
                                  </td>";
                        }
                        echo "</tr>";
                    }
                } else {
                    $colspan = $isLoggedIn ? 6 : 5;
                    echo "<tr><td colspan='{$colspan}' class='text-center'>No records found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
}
?>
